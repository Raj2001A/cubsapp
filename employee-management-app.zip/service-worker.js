// Service Worker for Employee Management App
const CACHE_NAME = 'emp-mgmt-cache-v2';

// For Vite, the assets are different from Create React App
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico'
  // Vite generates hashed filenames, so we'll cache them dynamically
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching static assets');
        // Cache each asset individually to prevent the entire operation from failing
        return Promise.all(
          STATIC_ASSETS.map(url => {
            // Fetch and cache each URL, but don't fail if one fails
            return fetch(url)
              .then(response => {
                if (response.ok) {
                  return cache.put(url, response);
                }
                console.warn(`Failed to cache ${url}: ${response.status} ${response.statusText}`);
                return Promise.resolve(); // Continue even if this asset fails
              })
              .catch(error => {
                console.warn(`Failed to fetch ${url} for caching:`, error);
                return Promise.resolve(); // Continue even if this asset fails
              });
          })
        );
      })
      .then(() => self.skipWaiting())
      .catch(error => {
        console.error('Service Worker installation failed:', error);
        // Still skip waiting to activate the service worker even if caching fails
        self.skipWaiting();
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];

  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheWhitelist.indexOf(cacheName) === -1) {
              console.log('Service Worker: Deleting old cache', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => self.clients.claim())
  );
});

// Fetch event - serve from cache or network
self.addEventListener('fetch', (event) => {
  // Skip non-GET requests and browser extensions
  if (event.request.method !== 'GET' ||
      !event.request.url.startsWith('http')) {
    return;
  }

  // Handle API requests differently from static assets
  if (event.request.url.includes('/api/')) {
    // Network-first strategy for API requests
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Clone the response to store in cache
          const responseToCache = response.clone();

          caches.open(CACHE_NAME)
            .then((cache) => {
              // Only cache successful responses
              if (response.status === 200) {
                cache.put(event.request, responseToCache);
              }
            });

          return response;
        })
        .catch(() => {
          // If network fails, try to serve from cache
          return caches.match(event.request)
            .then((cachedResponse) => {
              if (cachedResponse) {
                // Add a custom header to indicate this is from cache
                const headers = new Headers(cachedResponse.headers);
                headers.append('X-From-Cache', 'true');

                return new Response(cachedResponse.body, {
                  status: cachedResponse.status,
                  statusText: cachedResponse.statusText,
                  headers: headers
                });
              }

              // If not in cache, return a custom offline response for API
              return new Response(
                JSON.stringify({
                  error: 'You are offline',
                  offline: true,
                  timestamp: new Date().toISOString()
                }),
                {
                  status: 503,
                  statusText: 'Service Unavailable',
                  headers: {
                    'Content-Type': 'application/json',
                    'X-From-Cache': 'true',
                    'X-Offline': 'true'
                  }
                }
              );
            });
        })
    );
  } else {
    // Cache-first strategy for static assets
    event.respondWith(
      caches.match(event.request)
        .then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }

          // If not in cache, fetch from network
          return fetch(event.request)
            .then((response) => {
              // Clone the response to store in cache
              const responseToCache = response.clone();

              caches.open(CACHE_NAME)
                .then((cache) => {
                  // Only cache successful responses
                  if (response.status === 200) {
                    cache.put(event.request, responseToCache);
                  }
                });

              return response;
            })
            .catch(() => {
              // If both cache and network fail for non-HTML requests, return a fallback
              if (!event.request.url.includes('.html')) {
                return new Response(
                  'Network error occurred',
                  {
                    status: 503,
                    statusText: 'Service Unavailable',
                    headers: {
                      'Content-Type': 'text/plain',
                      'X-Offline': 'true'
                    }
                  }
                );
              }

              // For HTML requests, return the offline page
              return caches.match('/offline.html');
            });
        })
    );
  }
});

// Handle messages from the client
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
